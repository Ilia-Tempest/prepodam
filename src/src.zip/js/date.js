$(function() {
	
  $.datepicker.setDefaults($.datepicker.regional['ru']);
  $('#datep').datepicker({
    showOn: "both",
    buttonImage: "../../img/school-program/Group.svg",
    buttonImageOnly: true
});
    
});