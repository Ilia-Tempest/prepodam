$('form#my_form > :checkbox').on('change', function() {
  var checkbox = $(this);
  var name = checkbox.prop('name');
  if (checkbox.is(':checked')) {
    $(':checkbox[name="' + name + '"]').not($(this)).prop({
      'checked': false,
      'required': false
    });
  }
});