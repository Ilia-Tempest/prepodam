
  var a,b;
  function foo(c) {
      if (a != c) {b = 0;a = c};
      b ^= 1;
      c.checked = b
  };
  
